var tz = function(ac){
  window.location.href = window.location.origin + '/article/?' + ac
}





;(function(){
  //HTTPS
  if(window.location.protocol == 'http:' && window.location.hostname != 'localhost'){
    window.location.protocol = 'https:';
  }
  // var html = ''
  // for (var i = 0;i < articles.length;i++){
  //   html = html + `<div class="item">
  //   <div class="pic">
  //     <div class="tag">` +  articles[i].label + `</div>
  //     <img src="` + articles[i].img + `" alt="">
  //   </div>
  //   <div class="info">
  //     <a href='./article/?` + (i+1).toString() + `' class="title">` + articles[i].name + `</a>
  //     <div class="display">` + articles[i].display + `</div>
  //     <div class="message">时间:` + articles[i].date + `<br>作者:` + articles[i].by + `</div>
  //     <button onclick='tz(` + (i+1).toString() + `)' class='read'>阅读全文</button>
  //   </div>
  // </div>`
  //   }
  // document.getElementById('articleList').innerHTML = html;
})();