;(function () {
  var request = new XMLHttpRequest();
  function list(blogs){
    var items = blogs.split('厸厸厸');
    var html = "";
    for (var i = 0;(i + 1) < items.length;i++){
      var itemc = items[i].split('龖龖龖')
      html = html + `<div class="item">
      <div class="pic">
        <div class="tag">` +  itemc[6] + `</div>
        <img src="` + itemc[7] + `" alt="很水的LOGO">
      </div>
      <div class="info">
        <a href='./article/?` + (i+1).toString() + `' class="title">` + itemc[0] + `</a>
        <div class="display">` + itemc[1] + `</div>
        <div class="message">时间:` + itemc[2] + `<br>作者:` + itemc[3] + `</div>
        <button onclick='tz(` + (i+1).toString() + `)' class='read'>阅读全文</button>
      </div>
    </div>`
    }
    // console.log(window.articles)
    // console.log(html)
    document.getElementById('articleList').innerHTML = html;
  }
  request.onreadystatechange = function () { // 状态发生变化时，函数被回调
    if (request.readyState === 4) { // 成功完成
      // 判断响应结果:
      // console.log(request.status)
      if (request.status === 200) {
          // 成功，通过responseText拿到响应的文本:
          return list(request.responseText);
      } else {
          // 失败，根据响应码判断失败原因:
          return request.status;
      }
    } else {
        // HTTP请求还在继续...
    }
  }

  // 发送请求:
  request.open('GET', '../models/check.php');
  request.send();
})();