$('.write').val('OKJO')
$('.code').html($('.write').val())
setInterval(function(){
  $('.code').html($('.write').val())
},100)

$('button.save').on('click',function(){
  var blob = new Blob([$('.write').val()], {type: "text/plain;charset=utf-8"});
  saveAs(blob, "code.txt");
})