if (md5(document.cookie) === "d0749aaba8b833466dfcbb0428e4f89c"){
  alert('Hello,SuperAdmin')
}
auth = function(){
  if (md5(document.getElementById('username').value)
   == 
   "87d45851925a662deab3dbac7a09f4a4"
   &&
   md5(document.getElementById('password').value)
   ==
   "6097b3057efa85c42641991735ab9907"
   &&
   md5(document.title) == "99fedb09f0f5da90e577784e5f9fdc23")
  {
    alert('AUTH')
    document.cookie = 'SUCCESS'
  }
}