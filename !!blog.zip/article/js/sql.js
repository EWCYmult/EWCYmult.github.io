;(function () {
    var articlefontsize = 17; //默认字体
    var article = window.location.search.split('?')[1];//获得?后的
    var request = new XMLHttpRequest();//Ajax
    function list(blogs){ 
      articles = new Array();//文章数组(格式：settings.js))
      var items = blogs.split('厸厸厸');//分割
      var html = "";//定义
      for (var i = 0;(i + 1) < items.length;i++){ //最后一项为空,so i+1
        var itemc = items[i].split('龖龖龖')//分割
        html = html + `<div class="item">
        <div class="pic">
          <div class="tag">` +  itemc[6] + `</div>
          <img src="` + itemc[7] + `" alt="很水的LOGO">
        </div>
        <div class="info">
          <a href='./article/?` + (i+1).toString() + `' class="title">` + itemc[0] + `</a>
          <div class="display">` + itemc[1] + `</div>
          <div class="message">时间:` + itemc[2] + `<br>作者:` + itemc[3] + `</div>
          <button onclick='tz(` + (i+1).toString() + `)' class='read'>阅读全文</button>
        </div>
      </div>` //插入
        articles.push({ //数组加入对象
          name : itemc[0],
          display : itemc[1],
          date : itemc[2],
          by : itemc[3],
          content : itemc[4],
          tags : itemc[5],
          label : itemc[6],
          img : itemc[7],
        })
      }

      var obj = articles[parseInt(article) - 1]; //获取文章对象
      
      var tags = obj.tags.split(',');//标签分割
      var html = ''; //定义, =''，否则undefined
      document.getElementById('breadcrumbItem').href = './?' + parseInt(article).toString();//导航
      document.getElementById('breadcrumbItem').innerText = obj.name;//导航
      for (var i = 0;i < tags.length;i++){ //循环插入标签label
        html = html + "<label id='articletag' class='tag'>" + tags[i] + "</label>"
      };
      document.getElementById('articletags').innerHTML = html;
      document.title = obj.name + ' - py博客 ←_←';
      document.getElementById('articletitle').innerHTML = obj.name;
      document.getElementById('articlecontent').innerHTML = obj.content;
      
    }
    request.onreadystatechange = function () { // 状态发生变化时，函数被回调
      if (request.readyState === 4) { // 成功完成
        // 判断响应结果:
        if (request.status === 200) {
            // 成功
            functions();
            return list(request.responseText);
        } else {
            // 失败
            return request.status;
            alert('文章获取失败')
        }
      } else {
          // HTTP请求还在继续...
      }
    }
    function functions(){
      download = function(){
        let ct = event.srcElement.parentElement.lastElementChild.textContent;
        var blob = new Blob([ct], {type: "text/plain;charset=utf-8"});
        saveAs(blob, "down.txt");
      }
      copy = function (){
      let ct = event.srcElement.parentElement.lastElementChild.textContent;
      event.srcElement.setAttribute('data-clipboard-text',ct)
      // event.srcElement.parentElement.firstElementChild.setAttribute('data-clipboard-text',ct);
      var clipboard = new ClipboardJS('.copy');
      clipboard.on('success',function(){
        alert('copied')
      });
      }
      fontPlus = function (){
        articlefontsize++;
        document.getElementById('article').style.fontSize = articlefontsize.toString() + 'px';
      };
      fontSubtract = function (){
        articlefontsize--;
        document.getElementById('article').style.fontSize = articlefontsize.toString() + 'px';
      };
      fontDef = function (){
        document.getElementById('article').style.fontSize = '17px';
        articlefontsize = 17;
      };
      pagePlus = function (){
        if (parseInt(article) == window.articles.length){
          alert('最后一页了')
        }else {
          window.location.search = '?' + (parseInt(article) + 1).toString()
        }
      };
      pageSubtract = function (){
        if (parseInt(article) == 1){
          alert('第一页')
        }else {
          window.location.search = '?' + (parseInt(article) - 1).toString()
        }
      };
    }
    // 发送请求:
    request.open('GET', '../models/check.php');
    request.send();
  })();