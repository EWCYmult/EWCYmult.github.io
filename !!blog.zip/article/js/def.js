;(function(){
  
  //SSL
  if(window.location.protocol == 'http:' && window.location.hostname != 'localhost'){
    window.location.protocol = 'https:'
  };
  //SSL

})();
