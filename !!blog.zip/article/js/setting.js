var articles = [
  { //文章1 游戏推荐 - Undertale
    name : '去除Win10系统桌面快捷方式小图标',
    display : '去除Win10系统桌面快捷方式小图标',
    date : '2018.7.13',
    by : 'BOX',
    content : `<p>咱装了win10系统之后,桌面的图标那个小箭头看着很不舒服,于是就花了点时间整理下了快捷去除的方式</p>
    <p>首先,在win10<系统桌面右键新建文本文档,把这段复制过去</p>
    <block>
    <button onclick='download()' class='btn download'>下载</button>
    <button onclick='copy()' class="btn copy" data-clipboard-text="23">复制</button>
    <div class='waitcopy'>
    reg add "HKEY_LOCAL_MACHINE\SOFTWARE\Microsoft\Windows\CurrentVersion\Explorer\Shell Icons" /v 29 /d "%systemroot%\system32\imageres.dll,197" /t reg_sz /f<br>
    taskkill /f /im explorer.exe<br>
    attrib -s -r -h "%userprofile%\AppData\Local\iconcache.db"<br>
    del "%userprofile%\AppData\Local\iconcache.db" /f /q<br>
    start explorer
    </div>
    </block>
    <p>复制粘贴完成后,回到桌面,右键文件重命名为xxx.bat,名称随意,完成后,接下来就是运行,还是右键菜单,以管理员身份运行,运行之后,什么都不用管,这个是自动关闭的,运行完之后是不是发现桌面上的图标上已经没有了小箭头。</p>
    <p>好了,感谢阅读</p>`,
    tags : `CMD,bat,Win10,桌面,快捷方式`,
    label : 'Windows10',
    img : 'https://timgsa.baidu.com/timg?image&quality=80&size=b9999_10000&sec=1532264630461&di=8643292643fdf9b080d687055ff85cfc&imgtype=0&src=http%3A%2F%2Fimg17.3lian.com%2Fd%2Ffile%2F201703%2F14%2Fec57ea435856409a210737cf55db058d.jpg'
  },
  { //文章2 CSS换行超出
    name : 'CSS文字超出范围',
    display : '解决CSS文字超出范围',
    date : '2018.7.15',
    by : 'BOX',
    content :`<p>CSS文字字体过大的时候可能会遇到文字超出{作者经历过很多回(⊙﹏⊙)}</p>
              <p>解决方法：在CSS里换行的元素加入以下CSS</p>
              <block>
              <button onclick='copy()' class="btn copy" data-clipboard-text="23">复制</button>
              <div class='waitcopy'>word-wrap:break-word;</div></block>
              <p>介绍：</p>
              <block>
              break-all:一律断单词<br>
              break-word:尝试换行(允许断单词)<br>
              keep-all:不允许断单词</block>`,
    tags : `CSS,HTML,word-warp`,
    label : 'CSS',
    img : 'https://ss3.bdstatic.com/70cFv8Sh_Q1YnxGkpoWK1HF6hhy/it/u=3679693874,3655584695&fm=27&gp=0.jpg'
  },
];
