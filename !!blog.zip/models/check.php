<?php
$servername = "localhost";
$username = "root";
$password = "root";
$conn = new mysqli($servername, $username, $password, "pyblog");
// mysqli_select_db("pyblog");
if ($conn->connect_error) {
    die("连接失败: " . $conn->connect_error);
} 
$sql = "SELECT `py`.* FROM `py`" ;
$result = $conn->query($sql);
// echo $result . "a";
if ($result->num_rows > 0) {
    // 输出数据
    while($row = $result->fetch_assoc()) {
        echo base64_decode($row["name"]) . "龖龖龖" . base64_decode($row["display"]) . "龖龖龖" . base64_decode($row["date"]) . "龖龖龖" . base64_decode($row["author"]) . "龖龖龖" . base64_decode($row["content"]) . "龖龖龖" . base64_decode($row["tags"]) . "龖龖龖" . base64_decode($row["label"]) . "龖龖龖" . base64_decode($row["img"]);
        echo "厸厸厸";
    }
} else {
    echo "0 结果";
}

?>